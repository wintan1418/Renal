# Healthroom Renal Centre — UI Rebuild Handoff

Two design prototypes to rebuild into the Rails app. Both are self-contained HTML
files that open in any browser (they load fonts from Google Fonts and the local
`support.js` runtime — that runtime is a prototyping helper, **not** something to
ship; rebuild the markup natively in Rails/ERB/ViewComponents/Hotwire).

## Files
- `Healthroom Renal Centre.dc.html` — public marketing website (Home, Services,
  Doctors, About, Blog, Contact + working booking modal).
- `Healthroom App.dc.html` — authenticated clinical SaaS app (5 roles: Patient,
  Doctor, Nurse, Receptionist, Admin) with dashboards, tables, charts, booking
  wizard, payment flow, live dialysis session, design-system screen.
- `support.js` — prototype runtime only. Do not port. Use the rendered DOM/markup
  as the spec.

## How to read the prototypes
Each file has two parts inside the `<x-dc>` … `</x-dc>` block:
1. **Template** — the HTML markup with `{{ }}` placeholders and `<sc-for>` / `<sc-if>`
   loops/conditionals. This is your component structure.
2. **Logic class** (`class Component extends DCLogic`) — all the sample data,
   handlers, and view-model arrays. This is your data shape + interaction spec.

To see any screen: open the file in a browser, sign in with a demo role button,
and click through the sidebar. Every screen is real (no placeholders).

## Design system (use these exact tokens)
Fonts: **Inter** (app) and **Schibsted Grotesk** + **Hanken Grotesk** (marketing).
```
Navy     #0B2437   (sidebar, headers, primary text)
Teal     #2B8B75   (primary brand, secondary buttons, success)
Orange   #E8773F   (primary CTA / accent)
Blue     #13507A   (info)
Purple   #9333EA   (clinical category)
Cream    #F5F0E8   (marketing warm bg)
Canvas   #F4F7F6   (app background)
Border   #E6ECEA
Success  #16A34A   Warn #D97706   Danger #DC2626
```
Radii: cards 16–22px, inputs/buttons 11–13px, pills 999px.
Numbers use tabular figures (`font-variant-numeric: tabular-nums`). Currency is ₦.
The in-app **Design System** screen (Admin → Design System) renders all tokens,
badges, buttons and icon chips live — treat it as the canonical reference.

## App architecture
- Auth → role-based routing. 5 roles, each with its own sidebar nav config.
- Shell: navy sidebar (role-aware nav, active state, badges) + sticky topbar
  (search, notifications, avatar/role menu).
- Many list screens share ONE generic table/card renderer fed by per-screen data
  (see `buildPageView()` in the app's logic class) — mirror that with a shared
  table/card component + per-controller data.
- Interactions to preserve: 3-step booking wizard, Paystack-style pay modal,
  live dialysis session timer, check-in toggle, chart tabs, table filters.

## Images
All image areas are striped placeholders labeled with what belongs there
(e.g. "hospital building / team photo", doctor headshots, blog thumbnails).
Swap in real assets during the rebuild.

## Suggested Rails mapping
- Roles → Devise + Pundit (or Rolify). One layout, role-scoped sidebar partial.
- Screens → controllers/actions matching the sidebar items.
- Generic table/card → a shared ViewComponent taking columns + rows.
- Live bits (dialysis timer, notifications) → Stimulus controllers / Turbo Streams.
